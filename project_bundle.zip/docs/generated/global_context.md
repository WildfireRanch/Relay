# Global Project Context

Relay uses this file as a sample manual context. Replace this text with your own project notes.
