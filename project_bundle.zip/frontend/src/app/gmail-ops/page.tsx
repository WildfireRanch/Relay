// File: app/gmail-ops/page.tsx

"use client";
import GmailOpsPanel from "@/components/GmailOps/GmailOpsPanel";
export default function GmailOpsPage() {
  return <GmailOpsPanel />;
}
