import Dashboard from "./Dashboard";
export default {
  title: "Dashboard/Main",
  component: Dashboard,
};
export const Default = () => <Dashboard />;
